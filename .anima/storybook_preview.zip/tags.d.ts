import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-tags': IconTags;
    }
}
/**
 * The icon component for the 'tags' icon
 */
export declare class IconTags extends Icon {
    constructor();
}

import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-dashboard-builder': IconDashboardBuilder;
    }
}
/**
 * The icon component for the 'dashboardBuilder' icon
 */
export declare class IconDashboardBuilder extends Icon {
    constructor();
}

import type { Meta, StoryObj } from '@storybook/html';
import type { AutoUpdateMode } from '@microsoft/fast-foundation';
import '../../all-components';
import { TooltipSeverity } from '../types';
declare const uniqueId: unique symbol;
declare type HTMLElementWithUniqueID = HTMLElement & {
    [uniqueId]: string;
};
interface TooltipArgs {
    visible: boolean;
    severity: keyof typeof TooltipSeverity;
    delay: number;
    value: string;
    autoUpdateMode: AutoUpdateMode;
    iconVisible: boolean;
    anchorRef: HTMLElementWithUniqueID;
    getUniqueId: (x: HTMLElementWithUniqueID) => string;
    content: 'simple' | 'complex';
}
declare const metadata: Meta<TooltipArgs>;
export default metadata;
export declare const tooltip: StoryObj<TooltipArgs>;

import type { Meta, StoryObj } from '@storybook/html';
import type { AutoUpdateMode } from '@microsoft/fast-foundation';
import '../../all-components';
import { TooltipStatus } from '../types';
interface TooltipArgs {
    visible: boolean;
    state: keyof typeof TooltipStatus;
    delay: number;
    tooltip: string;
    autoUpdateMode: AutoUpdateMode;
    icon: boolean;
}
declare const metadata: Meta<TooltipArgs>;
export default metadata;
export declare const tooltip: StoryObj<TooltipArgs>;
export declare const complexContentTooltip: StoryObj<TooltipArgs>;

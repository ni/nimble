import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-share-square': IconShareSquare;
    }
}
/**
 * The icon component for the 'shareSquare' icon
 */
export declare class IconShareSquare extends Icon {
    constructor();
}

import { Orientation } from '@microsoft/fast-web-utilities';
import type { Meta, StoryObj } from '@storybook/html';
import '../../all-components';
interface RadioGroupArgs {
    label: string;
    orientation: Orientation;
    disabled: boolean;
    name: string;
    value: string;
}
declare const metadata: Meta<RadioGroupArgs>;
export default metadata;
export declare const radioGroup: StoryObj<RadioGroupArgs>;

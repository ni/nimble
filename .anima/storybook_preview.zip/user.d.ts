import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-user': IconUser;
    }
}
/**
 * The icon component for the 'user' icon
 */
export declare class IconUser extends Icon {
    constructor();
}

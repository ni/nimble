import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-comment': IconComment;
    }
}
/**
 * The icon component for the 'comment' icon
 */
export declare class IconComment extends Icon {
    constructor();
}

import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-question': IconQuestion;
    }
}
/**
 * The icon component for the 'question' icon
 */
export declare class IconQuestion extends Icon {
    constructor();
}

import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-info': IconInfo;
    }
}
/**
 * The icon component for the 'info' icon
 */
export declare class IconInfo extends Icon {
    constructor();
}

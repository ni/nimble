import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-cog-database-inset': IconCogDatabaseInset;
    }
}
/**
 * The icon component for the 'cogDatabaseInset' icon
 */
export declare class IconCogDatabaseInset extends Icon {
    constructor();
}

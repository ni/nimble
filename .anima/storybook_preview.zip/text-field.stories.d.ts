import type { Meta, StoryObj } from '@storybook/html';
import '../../all-components';
interface TextFieldArgs {
    label: string;
    type: string;
    appearance: string;
    'clear-inline-padding': boolean;
    value: string;
    readonly: boolean;
    disabled: boolean;
    invalid: boolean;
    'error-text': string;
    actionButton: boolean;
    leftIcon: boolean;
}
declare const metadata: Meta<TextFieldArgs>;
export default metadata;
export declare const underlineTextField: StoryObj<TextFieldArgs>;
export declare const blockTextField: StoryObj<TextFieldArgs>;
export declare const outlineTextField: StoryObj<TextFieldArgs>;
export declare const framelessTextField: StoryObj<TextFieldArgs>;
export declare const passwordField: StoryObj<TextFieldArgs>;

import type { Meta, StoryObj } from '@storybook/html';
import { TreeViewSelectionMode } from '../types';
import '../../all-components';
interface TreeArgs {
    selectionMode: TreeViewSelectionMode;
    options: ItemArgs[];
}
interface ItemArgs {
    label: string;
    value: string;
    disabled: boolean;
    icon: boolean;
    expanded: boolean;
}
declare const metadata: Meta<TreeArgs>;
export default metadata;
export declare const treeItem: StoryObj<ItemArgs>;
export declare const multipleTreeItems: StoryObj<TreeArgs>;

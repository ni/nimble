import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-folder-open': IconFolderOpen;
    }
}
/**
 * The icon component for the 'folderOpen' icon
 */
export declare class IconFolderOpen extends Icon {
    constructor();
}

import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-bell-circle': IconBellCircle;
    }
}
/**
 * The icon component for the 'bellCircle' icon
 */
export declare class IconBellCircle extends Icon {
    constructor();
}

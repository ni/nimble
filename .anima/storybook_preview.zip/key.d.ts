import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-key': IconKey;
    }
}
/**
 * The icon component for the 'key' icon
 */
export declare class IconKey extends Icon {
    constructor();
}

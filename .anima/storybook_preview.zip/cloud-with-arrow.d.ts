import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-cloud-with-arrow': IconCloudWithArrow;
    }
}
/**
 * The icon component for the 'cloudWithArrow' icon
 */
export declare class IconCloudWithArrow extends Icon {
    constructor();
}

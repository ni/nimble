import type { Tooltip } from '.';
export declare const template: import("@microsoft/fast-element").ViewTemplate<Tooltip, any>;

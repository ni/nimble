import { ViewTemplate } from '@microsoft/fast-element';
import type { FoundationElementTemplate } from '@microsoft/fast-foundation';
import type { MenuButton } from '.';
export declare const template: FoundationElementTemplate<ViewTemplate<MenuButton>>;

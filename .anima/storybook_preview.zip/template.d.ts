import type { ThemeProvider } from '.';
export declare const template: import("@microsoft/fast-element").ViewTemplate<ThemeProvider, any>;

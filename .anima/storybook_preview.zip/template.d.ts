import type { MenuButton } from '.';
export declare const template: import("@microsoft/fast-element").ViewTemplate<MenuButton, any>;

import type { TabsToolbar } from '.';
export declare const template: import("@microsoft/fast-element").ViewTemplate<TabsToolbar, any>;

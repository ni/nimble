import type { Icon } from '.';
export declare const template: import("@microsoft/fast-element").ViewTemplate<Icon, any>;

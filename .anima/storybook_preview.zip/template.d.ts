import { ViewTemplate } from '@microsoft/fast-element';
import { FoundationElementTemplate, ButtonOptions } from '@microsoft/fast-foundation';
import type { ToggleButton } from '.';
export declare const template: FoundationElementTemplate<ViewTemplate<ToggleButton>, ButtonOptions>;

import type { Drawer } from '.';
export declare const template: import("@microsoft/fast-element").ViewTemplate<Drawer<void>, any>;

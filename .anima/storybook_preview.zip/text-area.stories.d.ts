import type { Meta, StoryObj } from '@storybook/html';
import { TextAreaAppearance, TextAreaResize } from '../types';
import '../../all-components';
interface TextAreaArgs {
    appearance: TextAreaAppearance;
    label: string;
    placeholder: string;
    value: string;
    readonly: boolean;
    disabled: boolean;
    spellcheck: boolean;
    resize: TextAreaResize;
    rows: number;
    cols: number;
    maxlength: number;
}
declare const metadata: Meta<TextAreaArgs>;
export default metadata;
export declare const outlineTextArea: StoryObj<TextAreaArgs>;
export declare const blockTextArea: StoryObj<TextAreaArgs>;

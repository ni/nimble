import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-magnifying-glass': IconMagnifyingGlass;
    }
}
/**
 * The icon component for the 'magnifyingGlass' icon
 */
export declare class IconMagnifyingGlass extends Icon {
    constructor();
}

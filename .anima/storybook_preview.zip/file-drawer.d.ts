import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-file-drawer': IconFileDrawer;
    }
}
/**
 * The icon component for the 'fileDrawer' icon
 */
export declare class IconFileDrawer extends Icon {
    constructor();
}

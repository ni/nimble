import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-tablet': IconTablet;
    }
}
/**
 * The icon component for the 'tablet' icon
 */
export declare class IconTablet extends Icon {
    constructor();
}

import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-list': IconList;
    }
}
/**
 * The icon component for the 'list' icon
 */
export declare class IconList extends Icon {
    constructor();
}

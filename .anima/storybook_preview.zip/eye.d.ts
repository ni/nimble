import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-eye': IconEye;
    }
}
/**
 * The icon component for the 'eye' icon
 */
export declare class IconEye extends Icon {
    constructor();
}

import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-exclamation-mark': IconExclamationMark;
    }
}
/**
 * The icon component for the 'exclamationMark' icon
 */
export declare class IconExclamationMark extends Icon {
    constructor();
}

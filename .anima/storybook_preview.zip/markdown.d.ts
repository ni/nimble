import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-markdown': IconMarkdown;
    }
}
/**
 * The icon component for the 'markdown' icon
 */
export declare class IconMarkdown extends Icon {
    constructor();
}

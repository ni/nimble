import type { Meta, StoryObj } from '@storybook/html';
import '..';
interface MenuButtonArgs {
    label: string;
    appearance: string;
    open: boolean;
    disabled: boolean;
    icon: boolean;
    contentHidden: boolean;
    endIcon: boolean;
    menuPosition: string;
}
declare const metadata: Meta<MenuButtonArgs>;
export default metadata;
export declare const outlineButton: StoryObj<MenuButtonArgs>;
export declare const ghostButton: StoryObj<MenuButtonArgs>;
export declare const blockButton: StoryObj<MenuButtonArgs>;
export declare const iconButton: StoryObj<MenuButtonArgs>;

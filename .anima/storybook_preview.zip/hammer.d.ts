import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-hammer': IconHammer;
    }
}
/**
 * The icon component for the 'hammer' icon
 */
export declare class IconHammer extends Icon {
    constructor();
}

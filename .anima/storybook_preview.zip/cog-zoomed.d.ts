import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-cog-zoomed': IconCogZoomed;
    }
}
/**
 * The icon component for the 'cogZoomed' icon
 */
export declare class IconCogZoomed extends Icon {
    constructor();
}

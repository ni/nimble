import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-minus': IconMinus;
    }
}
/**
 * The icon component for the 'minus' icon
 */
export declare class IconMinus extends Icon {
    constructor();
}

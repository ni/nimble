import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-webvi-custom': IconWebviCustom;
    }
}
/**
 * The icon component for the 'webviCustom' icon
 */
export declare class IconWebviCustom extends Icon {
    constructor();
}

import type { Meta, StoryObj } from '@storybook/html';
import '../../all-components';
declare const metadata: Meta;
export default metadata;
export declare const baseColors: StoryObj;

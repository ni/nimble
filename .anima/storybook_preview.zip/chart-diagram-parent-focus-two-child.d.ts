import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-chart-diagram-parent-focus-two-child': IconChartDiagramParentFocusTwoChild;
    }
}
/**
 * The icon component for the 'chartDiagramParentFocusTwoChild' icon
 */
export declare class IconChartDiagramParentFocusTwoChild extends Icon {
    constructor();
}

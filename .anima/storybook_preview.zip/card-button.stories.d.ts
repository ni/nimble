import type { Meta, StoryObj } from '@storybook/html';
import '../../all-components';
interface CardButtonArgs {
    disabled: boolean;
    selected: boolean;
}
declare const metadata: Meta<CardButtonArgs>;
export default metadata;
export declare const cardButton: StoryObj<CardButtonArgs>;

import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-three-vertical-lines': IconThreeVerticalLines;
    }
}
/**
 * The icon component for the 'threeVerticalLines' icon
 */
export declare class IconThreeVerticalLines extends Icon {
    constructor();
}

import type { Meta, StoryObj } from '@storybook/html';
import { ButtonAppearance, ButtonAppearanceVariant } from '../types';
import '../../all-components';
interface ButtonArgs {
    label: string;
    appearance: keyof typeof ButtonAppearance;
    appearanceVariant: keyof typeof ButtonAppearanceVariant;
    disabled: boolean;
    icon: boolean;
    contentHidden: boolean;
    endIcon: boolean;
}
declare const metadata: Meta<ButtonArgs>;
export default metadata;
export declare const outlineButton: StoryObj<ButtonArgs>;
export declare const ghostButton: StoryObj<ButtonArgs>;
export declare const blockButton: StoryObj<ButtonArgs>;
export declare const iconButton: StoryObj<ButtonArgs>;

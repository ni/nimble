import type { Meta, StoryObj } from '@storybook/html';
import { PropertyFormat } from './types';
import '../../all-components';
interface TokenArgs {
    propertyFormat: PropertyFormat;
}
declare const metadata: Meta;
export default metadata;
export declare const themeAwareTokens: StoryObj<TokenArgs>;

import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-signal-bars': IconSignalBars;
    }
}
/**
 * The icon component for the 'signalBars' icon
 */
export declare class IconSignalBars extends Icon {
    constructor();
}

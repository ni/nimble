import type { Meta, StoryObj } from '@storybook/html';
import '../../all-components';
interface SwitchArgs {
    label: string;
    checked: boolean;
    disabled: boolean;
    checkedMessage: string;
    uncheckedMessage: string;
}
declare const metadata: Meta<SwitchArgs>;
export default metadata;
export declare const switchStory: StoryObj<SwitchArgs>;

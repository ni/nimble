import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-hourglass': IconHourglass;
    }
}
/**
 * The icon component for the 'hourglass' icon
 */
export declare class IconHourglass extends Icon {
    constructor();
}

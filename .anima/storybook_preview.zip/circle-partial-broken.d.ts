import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-circle-partial-broken': IconCirclePartialBroken;
    }
}
/**
 * The icon component for the 'circlePartialBroken' icon
 */
export declare class IconCirclePartialBroken extends Icon {
    constructor();
}

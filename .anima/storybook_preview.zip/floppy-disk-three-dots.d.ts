import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-floppy-disk-three-dots': IconFloppyDiskThreeDots;
    }
}
/**
 * The icon component for the 'floppyDiskThreeDots' icon
 */
export declare class IconFloppyDiskThreeDots extends Icon {
    constructor();
}

import { ViewTemplate } from '@microsoft/fast-element';
/**
 * Applies a style to customize text for all elements
 */
export declare const textCustomizationWrapper: {
    (template: ViewTemplate): ViewTemplate;
    parameters: any;
};

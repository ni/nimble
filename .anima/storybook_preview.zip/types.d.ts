/**
 * Symbol that is returned as the close reason (from the Promise returned by show()) when
 * the dialog or drawer was closed by pressing the ESC key (vs. calling the close() function).
 */
export declare const UserDismissed: unique symbol;
export declare type UserDismissed = typeof UserDismissed;

import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-mobile': IconMobile;
    }
}
/**
 * The icon component for the 'mobile' icon
 */
export declare class IconMobile extends Icon {
    constructor();
}

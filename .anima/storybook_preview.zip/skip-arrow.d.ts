import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-skip-arrow': IconSkipArrow;
    }
}
/**
 * The icon component for the 'skipArrow' icon
 */
export declare class IconSkipArrow extends Icon {
    constructor();
}

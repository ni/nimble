import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-cloud': IconCloud;
    }
}
/**
 * The icon component for the 'cloud' icon
 */
export declare class IconCloud extends Icon {
    constructor();
}

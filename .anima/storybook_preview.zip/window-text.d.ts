import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-window-text': IconWindowText;
    }
}
/**
 * The icon component for the 'windowText' icon
 */
export declare class IconWindowText extends Icon {
    constructor();
}

import { ViewTemplate } from '@microsoft/fast-element';
import type { Story } from '@storybook/html';
import { BackgroundState } from './states';
/**
 *  Renders a FAST `html` template as a story.
 */
export declare const createStory: {
    <TSource>(viewTemplate: ViewTemplate<TSource, any>): Story<TSource>;
    parameters: any;
};
/**
 *  Renders a FAST `html` template as a story that responds to the
 *  background theme selection in Storybook.
 */
export declare const createUserSelectedThemeStory: {
    <TSource>(viewTemplate: ViewTemplate<TSource, any>): Story<TSource>;
    parameters: any;
};
/**
 * Renders a FAST `html` template with a a specific theme.
 * Useful when the template can't be tested multiple times in a single story
 * and instead the test is broken up across multiple stories.
 */
export declare const createFixedThemeStory: {
    <TSource>(viewTemplate: ViewTemplate<TSource, any>, backgroundState: BackgroundState): Story<TSource>;
    parameters: any;
};
/**
 *  Renders a FAST `html` template for each theme.
 */
export declare const createMatrixThemeStory: {
    <TSource>(viewTemplate: ViewTemplate<TSource, any>): Story<TSource>;
    parameters: any;
};
export declare const overrideWarning: {
    (propertySummaryName: string, howToOverride: string): string;
    parameters: any;
};

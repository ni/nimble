import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-cog': IconCog;
    }
}
/**
 * The icon component for the 'cog' icon
 */
export declare class IconCog extends Icon {
    constructor();
}

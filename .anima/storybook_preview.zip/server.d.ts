import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-server': IconServer;
    }
}
/**
 * The icon component for the 'server' icon
 */
export declare class IconServer extends Icon {
    constructor();
}

import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-file-search': IconFileSearch;
    }
}
/**
 * The icon component for the 'fileSearch' icon
 */
export declare class IconFileSearch extends Icon {
    constructor();
}

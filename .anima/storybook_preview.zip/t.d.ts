import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-t': IconT;
    }
}
/**
 * The icon component for the 't' icon
 */
export declare class IconT extends Icon {
    constructor();
}

import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-clone': IconClone;
    }
}
/**
 * The icon component for the 'clone' icon
 */
export declare class IconClone extends Icon {
    constructor();
}

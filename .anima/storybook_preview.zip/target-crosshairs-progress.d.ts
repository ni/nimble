import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-target-crosshairs-progress': IconTargetCrosshairsProgress;
    }
}
/**
 * The icon component for the 'targetCrosshairsProgress' icon
 */
export declare class IconTargetCrosshairsProgress extends Icon {
    constructor();
}

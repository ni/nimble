import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-chart-diagram-child-focus': IconChartDiagramChildFocus;
    }
}
/**
 * The icon component for the 'chartDiagramChildFocus' icon
 */
export declare class IconChartDiagramChildFocus extends Icon {
    constructor();
}

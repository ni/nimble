import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-indeterminant-checkbox': IconIndeterminantCheckbox;
    }
}
/**
 * The icon component for the 'indeterminantCheckbox' icon
 */
export declare class IconIndeterminantCheckbox extends Icon {
    constructor();
}

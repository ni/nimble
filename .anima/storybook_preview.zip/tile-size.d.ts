import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-tile-size': IconTileSize;
    }
}
/**
 * The icon component for the 'tileSize' icon
 */
export declare class IconTileSize extends Icon {
    constructor();
}

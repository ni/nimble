import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-fancy-a': IconFancyA;
    }
}
/**
 * The icon component for the 'fancyA' icon
 */
export declare class IconFancyA extends Icon {
    constructor();
}

import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-laptop': IconLaptop;
    }
}
/**
 * The icon component for the 'laptop' icon
 */
export declare class IconLaptop extends Icon {
    constructor();
}

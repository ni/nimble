import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-floppy-disk-star-arrow-right': IconFloppyDiskStarArrowRight;
    }
}
/**
 * The icon component for the 'floppyDiskStarArrowRight' icon
 */
export declare class IconFloppyDiskStarArrowRight extends Icon {
    constructor();
}

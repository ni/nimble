import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-notebook': IconNotebook;
    }
}
/**
 * The icon component for the 'notebook' icon
 */
export declare class IconNotebook extends Icon {
    constructor();
}

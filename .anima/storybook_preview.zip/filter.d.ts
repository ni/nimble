import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-filter': IconFilter;
    }
}
/**
 * The icon component for the 'filter' icon
 */
export declare class IconFilter extends Icon {
    constructor();
}

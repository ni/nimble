import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-database-check': IconDatabaseCheck;
    }
}
/**
 * The icon component for the 'databaseCheck' icon
 */
export declare class IconDatabaseCheck extends Icon {
    constructor();
}

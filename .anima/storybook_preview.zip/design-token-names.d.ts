/**
 * Design token names should follow the token naming convention:
 * See: https://github.com/ni/nimble/blob/main/packages/nimble-components/CONTRIBUTING.md#token-naming
 */
import type * as TokensNamespace from './design-tokens';
declare type TokenName = keyof typeof TokensNamespace;
export declare const tokenNames: {
    readonly [key in TokenName]: string;
};
export declare const styleNameFromTokenName: {
    (tokenName: string): string;
    parameters: any;
};
export declare const cssPropertyFromTokenName: {
    (tokenName: string): string;
    parameters: any;
};
export declare const scssPropertyFromTokenName: {
    (tokenName: string): string;
    parameters: any;
};
export declare const scssInternalPropertyFromTokenName: {
    (tokenName: string): string;
    parameters: any;
};
export declare const scssInternalPropertySetterMarkdown: {
    (tokenName: string, property: string): string;
    parameters: any;
};
declare const tokenSuffixes: readonly ["RgbPartialColor", "FontColor", "FontLineHeight", "FontWeight", "FontSize", "TextTransform", "FontFamily", "Font", "Size", "Width", "Height", "Delay", "Padding", "Color"];
export declare type TokenSuffix = typeof tokenSuffixes[number];
export declare const suffixFromTokenName: {
    (tokenName: string): TokenSuffix | undefined;
    parameters: any;
};
export {};

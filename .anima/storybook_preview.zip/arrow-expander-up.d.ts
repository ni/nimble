import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-arrow-expander-up': IconArrowExpanderUp;
    }
}
/**
 * The icon component for the 'arrowExpanderUp' icon
 */
export declare class IconArrowExpanderUp extends Icon {
    constructor();
}

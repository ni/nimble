import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-calendar': IconCalendar;
    }
}
/**
 * The icon component for the 'calendar' icon
 */
export declare class IconCalendar extends Icon {
    constructor();
}

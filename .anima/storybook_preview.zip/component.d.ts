export declare const clickElement: {
    (element: HTMLElement): Promise<void>;
    parameters: any;
};

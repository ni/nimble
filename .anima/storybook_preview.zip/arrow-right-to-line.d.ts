import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-arrow-right-to-line': IconArrowRightToLine;
    }
}
/**
 * The icon component for the 'arrowRightToLine' icon
 */
export declare class IconArrowRightToLine extends Icon {
    constructor();
}

import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-circle-x': IconCircleX;
    }
}
/**
 * The icon component for the 'circleX' icon
 */
export declare class IconCircleX extends Icon {
    constructor();
}

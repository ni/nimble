import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-upload': IconUpload;
    }
}
/**
 * The icon component for the 'upload' icon
 */
export declare class IconUpload extends Icon {
    constructor();
}

import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-lock': IconLock;
    }
}
/**
 * The icon component for the 'lock' icon
 */
export declare class IconLock extends Icon {
    constructor();
}

import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-copy-text': IconCopyText;
    }
}
/**
 * The icon component for the 'copyText' icon
 */
export declare class IconCopyText extends Icon {
    constructor();
}

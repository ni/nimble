import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-grid-three-by-three': IconGridThreeByThree;
    }
}
/**
 * The icon component for the 'gridThreeByThree' icon
 */
export declare class IconGridThreeByThree extends Icon {
    constructor();
}

import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-shield-xmark': IconShieldXmark;
    }
}
/**
 * The icon component for the 'shieldXmark' icon
 */
export declare class IconShieldXmark extends Icon {
    constructor();
}

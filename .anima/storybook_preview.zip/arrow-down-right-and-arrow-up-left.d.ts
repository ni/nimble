import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-arrow-down-right-and-arrow-up-left': IconArrowDownRightAndArrowUpLeft;
    }
}
/**
 * The icon component for the 'arrowDownRightAndArrowUpLeft' icon
 */
export declare class IconArrowDownRightAndArrowUpLeft extends Icon {
    constructor();
}

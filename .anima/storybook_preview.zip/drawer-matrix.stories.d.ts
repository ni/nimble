import type { Meta, Story } from '@storybook/html';
import '../../all-components';
declare const metadata: Meta;
export default metadata;
export declare const drawerLightThemeWhiteBackground: Story;
export declare const drawerColorThemeDarkGreenBackground: Story;
export declare const drawerDarkThemeBlackBackground: Story;

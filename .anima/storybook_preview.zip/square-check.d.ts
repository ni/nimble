import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-square-check': IconSquareCheck;
    }
}
/**
 * The icon component for the 'squareCheck' icon
 */
export declare class IconSquareCheck extends Icon {
    constructor();
}

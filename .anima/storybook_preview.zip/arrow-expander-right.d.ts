import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-arrow-expander-right': IconArrowExpanderRight;
    }
}
/**
 * The icon component for the 'arrowExpanderRight' icon
 */
export declare class IconArrowExpanderRight extends Icon {
    constructor();
}

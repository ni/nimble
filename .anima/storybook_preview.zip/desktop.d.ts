import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-desktop': IconDesktop;
    }
}
/**
 * The icon component for the 'desktop' icon
 */
export declare class IconDesktop extends Icon {
    constructor();
}

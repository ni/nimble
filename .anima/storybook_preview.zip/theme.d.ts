import type { Behavior, ElementStyles, FASTElement } from '@microsoft/fast-element';
import type { Theme } from '../../theme-provider/types';
/**
 * Behavior to conditionally apply theme-based stylesheets.
 */
declare class ThemeStyleSheetBehavior implements Behavior {
    private readonly theme;
    private readonly styles;
    private readonly cache;
    constructor(theme: Theme | Theme[], styles: ElementStyles);
    /**
     * @internal
     */
    bind(source: FASTElement & HTMLElement): void;
    /**
     * @internal
     */
    unbind(source: FASTElement & HTMLElement): void;
}
/**
 * Behavior to conditionally apply theme-based stylesheets. To determine which to apply,
 * the behavior will use the nearest ThemeProvider's 'theme' design system value.
 *
 * @public
 * @example
 * ```ts
 * css`
 *     // ...
 * `.withBehaviors(
 *     themeBehavior(Theme.light, css` ... `),
 *     // Apply style for both dark and color theme
 *     themeBehavior([Theme.dark, Theme.color], css` ... `)
 * )
 * ```
 */
export declare const themeBehavior: {
    (theme: Theme | Theme[], styles: ElementStyles): ThemeStyleSheetBehavior;
    parameters: any;
};
export {};

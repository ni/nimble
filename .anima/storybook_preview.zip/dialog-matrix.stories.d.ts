import type { Meta, Story } from '@storybook/html';
import '../../all-components';
declare const metadata: Meta;
export default metadata;
export declare const dialogLightThemeWhiteBackground: Story;
export declare const dialogColorThemeDarkGreenBackground: Story;
export declare const dialogDarkThemeBlackBackground: Story;

import { ViewTemplate } from '@microsoft/fast-element';
/**
 * Wraps a given component template with a border and a message indicating
 * that the component is expected to be hidden.
 */
export declare const hiddenWrapper: {
    (template: ViewTemplate): ViewTemplate;
    parameters: any;
};

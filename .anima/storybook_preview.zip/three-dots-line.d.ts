import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-three-dots-line': IconThreeDotsLine;
    }
}
/**
 * The icon component for the 'threeDotsLine' icon
 */
export declare class IconThreeDotsLine extends Icon {
    constructor();
}

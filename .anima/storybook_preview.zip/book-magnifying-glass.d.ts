import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-book-magnifying-glass': IconBookMagnifyingGlass;
    }
}
/**
 * The icon component for the 'bookMagnifyingGlass' icon
 */
export declare class IconBookMagnifyingGlass extends Icon {
    constructor();
}

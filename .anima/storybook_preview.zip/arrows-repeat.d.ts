import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-arrows-repeat': IconArrowsRepeat;
    }
}
/**
 * The icon component for the 'arrowsRepeat' icon
 */
export declare class IconArrowsRepeat extends Icon {
    constructor();
}

import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-xmark-check': IconXmarkCheck;
    }
}
/**
 * The icon component for the 'xmarkCheck' icon
 */
export declare class IconXmarkCheck extends Icon {
    constructor();
}

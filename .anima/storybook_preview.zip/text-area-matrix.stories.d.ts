import type { Story, Meta } from '@storybook/html';
import '../../all-components';
declare const metadata: Meta;
export default metadata;
export declare const textAreaThemeMatrix: Story;
export declare const textAreaSizing: Story;
export declare const hiddenTextArea: Story;

import type { Behavior, ElementStyles } from '@microsoft/fast-element';
/**
 * Behavior that will conditionally apply a stylesheet based on the element's
 * appearance property
 *
 * @param value - The value or values of the appearance property
 * @param styles - The styles to be applied when condition matches
 *
 * @public
 */
export declare const appearanceBehavior: {
    <AppearanceType>(value: AppearanceType | AppearanceType[], styles: ElementStyles): Behavior;
    parameters: any;
};

import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-circle': IconCircle;
    }
}
/**
 * The icon component for the 'circle' icon
 */
export declare class IconCircle extends Icon {
    constructor();
}

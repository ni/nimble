import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-check-dot': IconCheckDot;
    }
}
/**
 * The icon component for the 'checkDot' icon
 */
export declare class IconCheckDot extends Icon {
    constructor();
}

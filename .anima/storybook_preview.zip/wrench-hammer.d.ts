import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-wrench-hammer': IconWrenchHammer;
    }
}
/**
 * The icon component for the 'wrenchHammer' icon
 */
export declare class IconWrenchHammer extends Icon {
    constructor();
}

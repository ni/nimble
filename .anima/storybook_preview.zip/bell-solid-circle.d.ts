import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-bell-solid-circle': IconBellSolidCircle;
    }
}
/**
 * The icon component for the 'bellSolidCircle' icon
 */
export declare class IconBellSolidCircle extends Icon {
    constructor();
}

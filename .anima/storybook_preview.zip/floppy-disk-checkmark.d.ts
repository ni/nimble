import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-floppy-disk-checkmark': IconFloppyDiskCheckmark;
    }
}
/**
 * The icon component for the 'floppyDiskCheckmark' icon
 */
export declare class IconFloppyDiskCheckmark extends Icon {
    constructor();
}

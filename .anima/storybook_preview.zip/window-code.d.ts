import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-window-code': IconWindowCode;
    }
}
/**
 * The icon component for the 'windowCode' icon
 */
export declare class IconWindowCode extends Icon {
    constructor();
}

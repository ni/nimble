import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-grid-two-by-two': IconGridTwoByTwo;
    }
}
/**
 * The icon component for the 'gridTwoByTwo' icon
 */
export declare class IconGridTwoByTwo extends Icon {
    constructor();
}

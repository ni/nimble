import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-chart-diagram': IconChartDiagram;
    }
}
/**
 * The icon component for the 'chartDiagram' icon
 */
export declare class IconChartDiagram extends Icon {
    constructor();
}

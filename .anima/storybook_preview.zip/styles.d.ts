import { ElementStyles } from '@microsoft/fast-element';
import { FoundationElementTemplate, TreeItemOptions } from '@microsoft/fast-foundation';
export declare const styles: FoundationElementTemplate<ElementStyles, TreeItemOptions>;

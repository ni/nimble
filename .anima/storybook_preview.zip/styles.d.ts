export declare const styles: import("@microsoft/fast-element").ElementStyles;

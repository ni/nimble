/**
 * Allows test code to wait for components to complete pending asynchronous updates that resulted
 * from DOM interactions like property or attribute changes.
 */
export declare const waitForUpdatesAsync: {
    (): Promise<void>;
    parameters: any;
};
/**
 * Allows test code to force components to synchronously complete normally asynchronous pending
 * updates that resulted from DOM interactions like property or attribute changes.
 */
export declare const processUpdates: {
    (): void;
    parameters: any;
};

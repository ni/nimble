import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-tag': IconTag;
    }
}
/**
 * The icon component for the 'tag' icon
 */
export declare class IconTag extends Icon {
    constructor();
}

import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-forward-slash': IconForwardSlash;
    }
}
/**
 * The icon component for the 'forwardSlash' icon
 */
export declare class IconForwardSlash extends Icon {
    constructor();
}

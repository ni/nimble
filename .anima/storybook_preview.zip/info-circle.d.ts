import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-info-circle': IconInfoCircle;
    }
}
/**
 * The icon component for the 'infoCircle' icon
 */
export declare class IconInfoCircle extends Icon {
    constructor();
}

import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-triangle': IconTriangle;
    }
}
/**
 * The icon component for the 'triangle' icon
 */
export declare class IconTriangle extends Icon {
    constructor();
}

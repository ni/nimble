/// <reference types="jasmine" />
declare type SpecTypes = typeof fit | typeof xit | typeof it;
/**
 * Used to focus or disable specific tests in a parameterized test run using a list of named objects.
 * In the following example the test for the `cats-and-dogs` case is focused for debugging
 * and no tests are disabled:
 * @example
 * const rainTypes = [
 *   { name: 'cats-and-dogs', type: 'idiom' },
 *   { name: 'frogs' type: 'idiom'},
 *   { name: 'men', type: 'lyrics'}
 * ] as const;
 * describe('Different rains', () => {
 *     const focused = ['cats-and-dogs'];
 *     const disabled = [];
 *     for (const rainType of rainTypes) {
 *         const specType = getSpecTypeByNamedList(rainType, focused, disabled);
 *         specType(`of type ${rainType.name} exist`, () => {
 *             expect(rainType.type).toBeDefined();
 *         });
 *     }
 * });
 */
export declare const getSpecTypeByNamedList: {
    <T extends {
        name: string;
    }>(value: T, focusList: string[], disabledList: string[]): SpecTypes;
    parameters: any;
};
export {};

import { ViewTemplate } from '@microsoft/fast-element';
export declare const sharedMatrixParameters: {
    (): {
        readonly controls: {
            readonly hideNoControlsWarning: true;
        };
        readonly a11y: {
            readonly disabled: true;
        };
        readonly docs: {
            readonly source: {
                readonly code: null;
            };
            readonly transformSource: (source: string) => string;
        };
        readonly backgrounds: {
            readonly disable: true;
            readonly grid: {
                readonly disable: true;
            };
        };
        readonly viewMode: "story";
        readonly previewTabs: {
            readonly 'storybook/docs/panel': {
                readonly hidden: true;
            };
        };
    };
    parameters: any;
};
/**
 * Takes an array of state values that can be used with the template to match the permutations of the provided states.
 */
export declare function createMatrix(component: () => ViewTemplate): ViewTemplate;
export declare function createMatrix<State1>(component: (state1: State1) => ViewTemplate, dimensions: readonly [readonly State1[]]): ViewTemplate;
export declare function createMatrix<State1, State2>(component: (state1: State1, state2: State2) => ViewTemplate, dimensions: readonly [readonly State1[], readonly State2[]]): ViewTemplate;
export declare function createMatrix<State1, State2, State3>(component: (state1: State1, state2: State2, state3: State3) => ViewTemplate, dimensions: readonly [
    readonly State1[],
    readonly State2[],
    readonly State3[]
]): ViewTemplate;
export declare function createMatrix<State1, State2, State3, State4>(component: (state1: State1, state2: State2, state3: State3, state4: State4) => ViewTemplate, dimensions: readonly [
    readonly State1[],
    readonly State2[],
    readonly State3[],
    readonly State4[]
]): ViewTemplate;
export declare function createMatrix<State1, State2, State3, State4, State5>(component: (state1: State1, state2: State2, state3: State3, state4: State4, state5: State5) => ViewTemplate, dimensions: readonly [
    readonly State1[],
    readonly State2[],
    readonly State3[],
    readonly State4[],
    readonly State5[]
]): ViewTemplate;
export declare function createMatrix<State1, State2, State3, State4, State5, State6>(component: (state1: State1, state2: State2, state3: State3, state4: State4, state5: State5, state6: State6) => ViewTemplate, dimensions: readonly [
    readonly State1[],
    readonly State2[],
    readonly State3[],
    readonly State4[],
    readonly State5[],
    readonly State6[]
]): ViewTemplate;
export declare function createMatrix<State1, State2, State3, State4, State5, State6, State7>(component: (state1: State1, state2: State2, state3: State3, state4: State4, state5: State5, state6: State6, state7: State7) => ViewTemplate, dimensions: readonly [
    readonly State1[],
    readonly State2[],
    readonly State3[],
    readonly State4[],
    readonly State5[],
    readonly State6[],
    readonly State7[]
]): ViewTemplate;
export declare function createMatrix<State1, State2, State3, State4, State5, State6, State7, State8>(component: (state1: State1, state2: State2, state3: State3, state4: State4, state5: State5, state6: State6, state7: State7, state8: State8) => ViewTemplate, dimensions: readonly [
    readonly State1[],
    readonly State2[],
    readonly State3[],
    readonly State4[],
    readonly State5[],
    readonly State6[],
    readonly State7[],
    readonly State8[]
]): ViewTemplate;
export declare function createMatrix<State1, State2, State3, State4, State5, State6, State7, State8, State9>(component: (state1: State1, state2: State2, state3: State3, state4: State4, state5: State5, state6: State6, state7: State7, state8: State8, state9: State9) => ViewTemplate, dimensions: readonly [
    readonly State1[],
    readonly State2[],
    readonly State3[],
    readonly State4[],
    readonly State5[],
    readonly State6[],
    readonly State7[],
    readonly State8[],
    readonly State9[]
]): ViewTemplate;
export declare const createMatrix: {
    (component: (...states: readonly unknown[]) => ViewTemplate, dimensions?: readonly (readonly unknown[])[] | undefined): ViewTemplate;
    parameters: any;
};

import type { Meta, StoryObj } from '@storybook/html';
import { IconStatus } from '../types';
interface IconArgs {
    status: IconStatus;
}
declare const metadata: Meta<IconArgs>;
export default metadata;
export declare const icons: StoryObj<IconArgs>;

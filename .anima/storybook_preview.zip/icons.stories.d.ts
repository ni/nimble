import type { Meta, StoryObj } from '@storybook/html';
import { IconSeverity } from '../types';
interface IconArgs {
    severity: keyof typeof IconSeverity;
}
declare const metadata: Meta<IconArgs>;
export default metadata;
export declare const icons: StoryObj<IconArgs>;

import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-link-cancel': IconLinkCancel;
    }
}
/**
 * The icon component for the 'linkCancel' icon
 */
export declare class IconLinkCancel extends Icon {
    constructor();
}

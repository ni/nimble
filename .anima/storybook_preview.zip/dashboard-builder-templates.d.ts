import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-dashboard-builder-templates': IconDashboardBuilderTemplates;
    }
}
/**
 * The icon component for the 'dashboardBuilderTemplates' icon
 */
export declare class IconDashboardBuilderTemplates extends Icon {
    constructor();
}

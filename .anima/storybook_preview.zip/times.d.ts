import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-times': IconTimes;
    }
}
/**
 * The icon component for the 'times' icon
 */
export declare class IconTimes extends Icon {
    constructor();
}

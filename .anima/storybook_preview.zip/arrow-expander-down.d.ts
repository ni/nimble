import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-arrow-expander-down': IconArrowExpanderDown;
    }
}
/**
 * The icon component for the 'arrowExpanderDown' icon
 */
export declare class IconArrowExpanderDown extends Icon {
    constructor();
}

import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-share-nodes': IconShareNodes;
    }
}
/**
 * The icon component for the 'shareNodes' icon
 */
export declare class IconShareNodes extends Icon {
    constructor();
}

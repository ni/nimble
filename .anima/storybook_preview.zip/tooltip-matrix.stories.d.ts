import type { Meta, Story } from '@storybook/html';
import '../../all-components';
declare const metadata: Meta;
export default metadata;
export declare const tooltipLightThemeWhiteBackground: Story;
export declare const tooltipColorThemeDarkGreenBackground: Story;
export declare const tooltipDarkThemeBlackBackground: Story;
export declare const hiddenTooltip: Story;

import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-circle-check': IconCircleCheck;
    }
}
/**
 * The icon component for the 'circleCheck' icon
 */
export declare class IconCircleCheck extends Icon {
    constructor();
}

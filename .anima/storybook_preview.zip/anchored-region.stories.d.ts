import type { Meta, StoryObj } from '@storybook/html';
import '../../all-components';
interface AnchoredRegionArgs {
    horizontalPosition: string;
    verticalPosition: string;
}
declare const metadata: Meta<AnchoredRegionArgs>;
export default metadata;
export declare const anchoredRegion: StoryObj<AnchoredRegionArgs>;

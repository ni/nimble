import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-dot-solid-dot-stroke': IconDotSolidDotStroke;
    }
}
/**
 * The icon component for the 'dotSolidDotStroke' icon
 */
export declare class IconDotSolidDotStroke extends Icon {
    constructor();
}

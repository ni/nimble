import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-arrow-partial-rotate-left': IconArrowPartialRotateLeft;
    }
}
/**
 * The icon component for the 'arrowPartialRotateLeft' icon
 */
export declare class IconArrowPartialRotateLeft extends Icon {
    constructor();
}

import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-check': IconCheck;
    }
}
/**
 * The icon component for the 'check' icon
 */
export declare class IconCheck extends Icon {
    constructor();
}

import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-dashboard-builder-legend': IconDashboardBuilderLegend;
    }
}
/**
 * The icon component for the 'dashboardBuilderLegend' icon
 */
export declare class IconDashboardBuilderLegend extends Icon {
    constructor();
}

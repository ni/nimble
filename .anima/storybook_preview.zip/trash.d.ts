import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-trash': IconTrash;
    }
}
/**
 * The icon component for the 'trash' icon
 */
export declare class IconTrash extends Icon {
    constructor();
}

/**
 * Static tokens to use for styling the `::backdrop` pseduo-element of an HTML dialog, which
 * does not have access to CSS custom properties.
 *
 * See https://github.com/whatwg/fullscreen/issues/124
 */
export declare const modalBackdropColorThemeLightStatic: string;
export declare const modalBackdropColorThemeDarkStatic: string;
export declare const modalBackdropColorThemeColorStatic: string;
export declare const largeDelayStatic: string;

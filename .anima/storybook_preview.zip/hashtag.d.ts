import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-hashtag': IconHashtag;
    }
}
/**
 * The icon component for the 'hashtag' icon
 */
export declare class IconHashtag extends Icon {
    constructor();
}

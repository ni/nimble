import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-square-t': IconSquareT;
    }
}
/**
 * The icon component for the 'squareT' icon
 */
export declare class IconSquareT extends Icon {
    constructor();
}

import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-chart-diagram-parent-focus': IconChartDiagramParentFocus;
    }
}
/**
 * The icon component for the 'chartDiagramParentFocus' icon
 */
export declare class IconChartDiagramParentFocus extends Icon {
    constructor();
}

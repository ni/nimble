import type { Meta, Story } from '@storybook/html';
import '../../all-components';
declare const metadata: Meta;
export default metadata;
export declare const radioGroupThemeMatrix: Story;
export declare const hiddenRadioGroup: Story;
export declare const hiddenRadio: Story;
export declare const textCustomized: Story;

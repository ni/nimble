import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-four-dots-square': IconFourDotsSquare;
    }
}
/**
 * The icon component for the 'fourDotsSquare' icon
 */
export declare class IconFourDotsSquare extends Icon {
    constructor();
}

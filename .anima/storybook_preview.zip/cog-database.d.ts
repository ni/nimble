import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-cog-database': IconCogDatabase;
    }
}
/**
 * The icon component for the 'cogDatabase' icon
 */
export declare class IconCogDatabase extends Icon {
    constructor();
}

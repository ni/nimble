import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-clock-triangle': IconClockTriangle;
    }
}
/**
 * The icon component for the 'clockTriangle' icon
 */
export declare class IconClockTriangle extends Icon {
    constructor();
}

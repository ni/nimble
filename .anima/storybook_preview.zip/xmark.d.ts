import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-xmark': IconXmark;
    }
}
/**
 * The icon component for the 'xmark' icon
 */
export declare class IconXmark extends Icon {
    constructor();
}

import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-home': IconHome;
    }
}
/**
 * The icon component for the 'home' icon
 */
export declare class IconHome extends Icon {
    constructor();
}

import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-electronic-chip-zoomed': IconElectronicChipZoomed;
    }
}
/**
 * The icon component for the 'electronicChipZoomed' icon
 */
export declare class IconElectronicChipZoomed extends Icon {
    constructor();
}

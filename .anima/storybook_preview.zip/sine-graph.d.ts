import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-sine-graph': IconSineGraph;
    }
}
/**
 * The icon component for the 'sineGraph' icon
 */
export declare class IconSineGraph extends Icon {
    constructor();
}

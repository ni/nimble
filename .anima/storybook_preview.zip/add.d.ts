import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-add': IconAdd;
    }
}
/**
 * The icon component for the 'add' icon
 */
export declare class IconAdd extends Icon {
    constructor();
}

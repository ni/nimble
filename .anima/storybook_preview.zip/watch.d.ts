import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-watch': IconWatch;
    }
}
/**
 * The icon component for the 'watch' icon
 */
export declare class IconWatch extends Icon {
    constructor();
}

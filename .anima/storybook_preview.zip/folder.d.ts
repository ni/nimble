import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-folder': IconFolder;
    }
}
/**
 * The icon component for the 'folder' icon
 */
export declare class IconFolder extends Icon {
    constructor();
}

import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-database': IconDatabase;
    }
}
/**
 * The icon component for the 'database' icon
 */
export declare class IconDatabase extends Icon {
    constructor();
}

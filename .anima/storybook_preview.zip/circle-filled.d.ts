import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-circle-filled': IconCircleFilled;
    }
}
/**
 * The icon component for the 'circleFilled' icon
 */
export declare class IconCircleFilled extends Icon {
    constructor();
}

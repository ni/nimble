import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-donut-chart': IconDonutChart;
    }
}
/**
 * The icon component for the 'donutChart' icon
 */
export declare class IconDonutChart extends Icon {
    constructor();
}

import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-function': IconFunction;
    }
}
/**
 * The icon component for the 'function' icon
 */
export declare class IconFunction extends Icon {
    constructor();
}

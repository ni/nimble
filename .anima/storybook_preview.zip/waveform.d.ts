import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-waveform': IconWaveform;
    }
}
/**
 * The icon component for the 'waveform' icon
 */
export declare class IconWaveform extends Icon {
    constructor();
}

import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-clipboard': IconClipboard;
    }
}
/**
 * The icon component for the 'clipboard' icon
 */
export declare class IconClipboard extends Icon {
    constructor();
}

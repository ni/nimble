import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-lightning-bolt': IconLightningBolt;
    }
}
/**
 * The icon component for the 'lightningBolt' icon
 */
export declare class IconLightningBolt extends Icon {
    constructor();
}

import type { Meta, Story } from '@storybook/html';
import '../../all-components';
declare const metadata: Meta;
export default metadata;
export declare const checkboxThemeMatrix: Story;
export declare const hiddenCheckbox: Story;
export declare const textCustomized: Story;

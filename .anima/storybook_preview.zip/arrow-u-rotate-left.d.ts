import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-arrow-u-rotate-left': IconArrowURotateLeft;
    }
}
/**
 * The icon component for the 'arrowURotateLeft' icon
 */
export declare class IconArrowURotateLeft extends Icon {
    constructor();
}

import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-arrows-maximize': IconArrowsMaximize;
    }
}
/**
 * The icon component for the 'arrowsMaximize' icon
 */
export declare class IconArrowsMaximize extends Icon {
    constructor();
}

import { RadioGroup as FoundationRadioGroup } from '@microsoft/fast-foundation';
import { Orientation } from '@microsoft/fast-web-utilities';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-radio-group': RadioGroup;
    }
}
export { Orientation };
/**
 * A nimble-styled grouping element for radio buttons
 */
export declare class RadioGroup extends FoundationRadioGroup {
}

import { DesignToken, FoundationElement } from '@microsoft/fast-foundation';
import { Direction } from '@microsoft/fast-web-utilities';
import { Theme } from './types';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-theme-provider': ThemeProvider;
    }
}
export declare const direction: DesignToken<Direction>;
export declare const theme: DesignToken<Theme>;
/**
 * The ThemeProvider implementation. Add this component to the page and set its `theme` attribute to control
 * the values of design tokens that provide colors and fonts as CSS custom properties to any descendant components.
 * @internal
 */
export declare class ThemeProvider extends FoundationElement {
    direction: Direction;
    theme: Theme;
    directionChanged(_prev: Direction | undefined, next: Direction | undefined): void;
    themeChanged(_prev: Theme | undefined, next: Theme | undefined): void;
}

import { DelegatesARIAButton, StartEnd, Switch as FoundationSwitch } from '@microsoft/fast-foundation';
import type { ButtonPattern } from '../patterns/button/types';
import { ButtonAppearance } from './types';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-toggle-button': ToggleButton;
    }
}
/**
 * A nimble-styled toggle button control.
 */
export declare class ToggleButton extends FoundationSwitch implements ButtonPattern {
    /**
     * @public
     * @remarks
     * HTML Attribute: appearance
     */
    appearance: ButtonAppearance;
    /**
     * @public
     * @remarks
     * HTML Attribute: content-hidden
     */
    contentHidden: boolean;
    /** @internal */
    readonly control: HTMLElement;
}
export interface ToggleButton extends StartEnd, DelegatesARIAButton {
}

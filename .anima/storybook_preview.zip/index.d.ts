import { Button as FoundationButton } from '@microsoft/fast-foundation';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-card-button': CardButton;
    }
}
/**
 * A nimble-styled card button
 */
export declare class CardButton extends FoundationButton {
    /**
     * @public
     * @remarks
     * HTML Attribute: selected
     */
    selected: boolean;
}

import { TextArea as FoundationTextArea } from '@microsoft/fast-foundation';
import { TextAreaAppearance } from './types';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-text-area': TextArea;
    }
}
/**
 * A nimble-styed HTML text area
 */
export declare class TextArea extends FoundationTextArea {
    /**
     * The appearance the text area should have.
     *
     * @public
     * @remarks
     * HTML Attribute: appearance
     */
    appearance: TextAreaAppearance;
}

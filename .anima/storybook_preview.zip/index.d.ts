import { FoundationElement } from '@microsoft/fast-foundation';
import type { NimbleIcon } from '@ni/nimble-tokens/dist/icons/js';
import type { IconSeverity } from './types';
/**
 * The base class for icon components
 */
export declare class Icon extends FoundationElement {
    readonly icon: NimbleIcon;
    /**
     * @public
     * @remarks
     * HTML Attribute: severity
     */
    severity: IconSeverity;
    constructor(/** @internal */ icon: NimbleIcon);
}
declare type IconClass = typeof Icon;
export declare const registerIcon: {
    (baseName: string, iconClass: IconClass): void;
    parameters: any;
};
export {};

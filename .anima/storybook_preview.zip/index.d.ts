import { MenuItem as FoundationMenuItem } from '@microsoft/fast-foundation';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-menu-item': MenuItem;
    }
}
/**
 * A nimble-styled menu-item
 */
export declare class MenuItem extends FoundationMenuItem {
}

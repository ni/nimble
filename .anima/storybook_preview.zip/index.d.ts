import { Combobox as FoundationCombobox } from '@microsoft/fast-foundation';
import type { ToggleButton } from '../toggle-button';
import '../icons/exclamation-mark';
import '../icons/arrow-expander-down';
import type { IHasErrorText } from '../patterns/error/types';
import { DropdownAppearance } from '../patterns/dropdown/types';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-combobox': Combobox;
    }
}
/**
 * A nimble-styed HTML combobox
 */
export declare class Combobox extends FoundationCombobox implements IHasErrorText {
    appearance: DropdownAppearance;
    /**
     * The ref to the internal dropdown button element.
     *
     * @internal
     */
    readonly dropdownButton?: ToggleButton;
    /**
     * A message explaining why the value is invalid.
     *
     * @public
     * @remarks
     * HTML Attribute: error-text
     */
    errorText: string | undefined;
    private valueUpdatedByInput;
    private valueBeforeTextUpdate?;
    setPositioning(): void;
    slottedOptionsChanged(prev: HTMLElement[], next: HTMLElement[]): void;
    connectedCallback(): void;
    toggleButtonClickHandler(e: Event): void;
    toggleButtonChangeHandler(e: Event): void;
    toggleButtonKeyDownHandler(e: KeyboardEvent): boolean;
    filterOptions(): void;
    /**
     * This is a workaround for the issue described here: https://github.com/microsoft/fast/issues/6267
     * For now, we will update the value ourselves while a user types in text. Note that there is other
     * implementation related to this (like the 'keydownEventHandler') needed to create the complete set
     * of desired behavior described in the issue noted above.
     */
    inputHandler(e: InputEvent): boolean | void;
    keydownHandler(e: KeyboardEvent): boolean | void;
    focusoutHandler(e: FocusEvent): boolean | void;
    protected openChanged(): void;
    private ariaLabelChanged;
    private updateInputAriaLabel;
    /**
     * This will only emit a `change` event after text entry where the text in the input prior to
     * typing is different than the text present upon an attempt to commit (e.g. pressing <Enter>).
     * So, for a concrete example:
     * 1) User types 'Sue' (when Combobox input was blank).
     * 2) User presses <Enter> -> 'change' event fires
     * 3) User deletes 'Sue'
     * 4) User re-types 'Sue'
     * 5) User presses <Enter> -> NO 'change' event is fired
     */
    private emitChangeIfValueUpdated;
}

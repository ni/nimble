import { FoundationElement } from '@microsoft/fast-foundation';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-tabs-toolbar': TabsToolbar;
    }
}
/**
 * A nimble-styled container for toolbar content next to tabs.
 */
export declare class TabsToolbar extends FoundationElement {
}

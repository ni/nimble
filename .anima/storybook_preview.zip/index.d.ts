import { Select as FoundationSelect } from '@microsoft/fast-foundation';
import { DropdownAppearance } from '../patterns/dropdown/types';
import type { ErrorPattern } from '../patterns/error/types';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-select': Select;
    }
}
/**
 * A nimble-styled HTML select
 */
export declare class Select extends FoundationSelect implements ErrorPattern {
    appearance: DropdownAppearance;
    /**
     * A message explaining why the value is invalid.
     *
     * @public
     * @remarks
     * HTML Attribute: error-text
     */
    errorText: string | undefined;
    errorVisible: boolean;
    setPositioning(): void;
    slottedOptionsChanged(prev: Element[], next: Element[]): void;
    private maxHeightChanged;
    private updateListboxMaxHeightCssVariable;
}

import { TextField as FoundationTextField } from '@microsoft/fast-foundation';
import { TextFieldAppearance } from './types';
import type { ErrorPattern } from '../patterns/error/types';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-text-field': TextField;
    }
}
/**
 * A nimble-styed HTML text input
 */
export declare class TextField extends FoundationTextField implements ErrorPattern {
    /**
     * The appearance the text field should have.
     *
     * @public
     * @remarks
     * HTML Attribute: appearance
     */
    appearance: TextFieldAppearance;
    /**
     * A message explaining why the value is invalid.
     *
     * @public
     * @remarks
     * HTML Attribute: error-text
     */
    errorText?: string;
    errorVisible: boolean;
    fullBleed: boolean;
}

import { Toolbar as FoundationToolbar } from '@microsoft/fast-foundation';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-toolbar': Toolbar;
    }
}
/**
 * A nimble-styled Toolbar
 */
export declare class Toolbar extends FoundationToolbar {
}

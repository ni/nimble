import { Breadcrumb as FoundationBreadcrumb } from '@microsoft/fast-foundation';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-breadcrumb': Breadcrumb;
    }
}
/**
 * A nimble-styled breadcrumb
 */
export declare class Breadcrumb extends FoundationBreadcrumb {
}

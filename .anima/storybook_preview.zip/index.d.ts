import { TabPanel as FoundationTabPanel } from '@microsoft/fast-foundation';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-tab-panel': TabPanel;
    }
}
/**
 * A nimble-styled tab panel
 */
export declare class TabPanel extends FoundationTabPanel {
}

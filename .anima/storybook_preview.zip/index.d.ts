import { Tooltip as FoundationTooltip } from '@microsoft/fast-foundation';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-tooltip': Tooltip;
    }
}
/**
 * A nimble-styled tooltip control.
 */
export declare class Tooltip extends FoundationTooltip {
}

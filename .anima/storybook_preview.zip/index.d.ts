import { Button as FoundationButton } from '@microsoft/fast-foundation';
import type { IButton } from '../patterns/button/types';
import { ButtonAppearance } from './types';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-button': Button;
    }
}
/**
 * A nimble-styled HTML button
 */
export declare class Button extends FoundationButton implements IButton {
    /**
     * @public
     * @remarks
     * HTML Attribute: appearance
     */
    appearance: ButtonAppearance;
    /**
     * @public
     * @remarks
     * HTML Attribute: content-hidden
     */
    contentHidden: boolean;
}

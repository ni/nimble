import { ListboxOption as FoundationListboxOption } from '@microsoft/fast-foundation';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-list-option': ListOption;
    }
}
/**
 * A nimble-styled HTML listbox option
 */
export declare class ListOption extends FoundationListboxOption {
    get value(): string;
    set value(value: string);
    connectedCallback(): void;
}

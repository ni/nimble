import { Tab as FoundationTab } from '@microsoft/fast-foundation';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-tab': Tab;
    }
}
/**
 * A nimble-styled HTML tab
 */
export declare class Tab extends FoundationTab {
}

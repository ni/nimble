import { Checkbox as FoundationCheckbox } from '@microsoft/fast-foundation';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-checkbox': Checkbox;
    }
}
/**
 * A nimble-styled checkbox control.
 */
export declare class Checkbox extends FoundationCheckbox {
}

import { FoundationElement } from '@microsoft/fast-foundation';
import { ButtonAppearance } from '../button/types';
import type { ToggleButton } from '../toggle-button';
import { MenuButtonPosition } from './types';
import type { IButton } from '../patterns/button/types';
import type { AnchoredRegion } from '../anchored-region';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-menu-button': MenuButton;
    }
}
/**
 * A nimble-styled menu button control.
 */
export declare class MenuButton extends FoundationElement implements IButton {
    appearance: ButtonAppearance;
    disabled: boolean;
    contentHidden: boolean;
    /**
     * Specifies whether or not the menu is open.
     */
    open: boolean;
    /**
     * Configures where the menu should be placed relative to the button that opens the menu.
     */
    position: MenuButtonPosition;
    /** @internal */
    readonly toggleButton: ToggleButton | undefined;
    /** @internal */
    readonly region: AnchoredRegion | undefined;
    /** @internal */
    readonly slottedMenus: HTMLElement[] | undefined;
    /**
     * Used to maintain the internal state of whether the last menu item should be focused instead
     * of the first menu item the next time the menu is opened.
     */
    private focusLastItemWhenOpened;
    disconnectedCallback(): void;
    toggleButtonChanged(_prev: ToggleButton | undefined, _next: ToggleButton | undefined): void;
    regionChanged(prev: AnchoredRegion | undefined, _next: AnchoredRegion | undefined): void;
    openChanged(_prev: boolean | undefined, _next: boolean): void;
    regionLoadedHandler(): void;
    focusoutHandler(e: FocusEvent): boolean;
    toggleButtonCheckedChangeHandler(e: Event): boolean;
    toggleButtonKeyDownHandler(e: KeyboardEvent): boolean;
    menuKeyDownHandler(e: KeyboardEvent): boolean;
    private get menu();
    private focusMenu;
    private focusLastMenuItem;
    private readonly menuChangeHandler;
}

import { Dialog as FoundationDialog } from '@microsoft/fast-foundation';
import { DrawerLocation, DrawerState } from './types';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-drawer': Drawer;
    }
}
/**
 * Drawer/Sidenav control. Shows content in a panel on the left / right side of the screen,
 * which animates to be visible with a slide-in / slide-out animation.
 * Configured via 'location', 'state', 'modal', 'preventDismiss' properties.
 */
export declare class Drawer extends FoundationDialog {
    location: DrawerLocation;
    state: DrawerState;
    /**
     * True to prevent dismissing the drawer when the overlay outside the drawer is clicked.
     * Only applicable when 'modal' is set to true (i.e. when the overlay is used).
     * HTML Attribute: prevent-dismiss
     */
    preventDismiss: boolean;
    private readonly propertiesToWatch;
    private propertyChangeNotifier?;
    private animationDurationMilliseconds;
    private animationGroup?;
    private animationsEnabledChangedHandler?;
    private propertyChangeSubscriber?;
    /** @internal */
    connectedCallback(): void;
    /** @internal */
    disconnectedCallback(): void;
    show(): void;
    hide(): void;
    /**
     * Handler for overlay clicks (user-initiated dismiss requests) only.
     * @internal
     */
    dismiss(): void;
    private onPropertyChange;
    private onHiddenChanged;
    private onLocationChanged;
    private onStateChanged;
    private updateAnimationDuration;
    private animateOpening;
    private animateClosing;
    private animateOpenClose;
    private cancelCurrentAnimation;
}

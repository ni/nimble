import { FoundationElement } from '@microsoft/fast-foundation';
import type { NimbleIcon } from '@ni/nimble-tokens/dist/icons/js';
/**
 * The base class for icon components
 */
export declare class Icon extends FoundationElement {
    icon: NimbleIcon;
    constructor(icon: NimbleIcon);
}
declare type IconClass = typeof Icon;
export declare const registerIcon: {
    (baseName: string, iconClass: IconClass): void;
    parameters: any;
};
export {};

import { Tooltip as FoundationTooltip } from '@microsoft/fast-foundation';
import type { TooltipSeverity } from './types';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-tooltip': Tooltip;
    }
}
/**
 * A nimble-styled tooltip control.
 */
export declare class Tooltip extends FoundationTooltip {
    /**
     * @public
     * @remarks
     * HTML Attribute: severity
     */
    severity: TooltipSeverity;
    iconVisible: boolean;
}

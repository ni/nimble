import { Button as FoundationButton } from '@microsoft/fast-foundation';
import type { ButtonPattern } from '../patterns/button/types';
import { ButtonAppearance, ButtonAppearanceVariant } from './types';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-button': Button;
    }
}
/**
 * A nimble-styled HTML button
 */
export declare class Button extends FoundationButton implements ButtonPattern {
    /**
     * @public
     * @remarks
     * HTML Attribute: appearance
     */
    appearance: ButtonAppearance;
    /**
     * @public
     * @remarks
     * HTML Attribute: appearance-variant
     */
    appearanceVariant: ButtonAppearanceVariant;
    /**
     * @public
     * @remarks
     * HTML Attribute: content-hidden
     */
    contentHidden: boolean;
}

import { TreeItem as FoundationTreeItem } from '@microsoft/fast-foundation';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-tree-item': TreeItem;
    }
}
/**
 * A function that returns a nimble-tree-item registration for configuring the component with a DesignSystem.
 * Implements {@link @microsoft/fast-foundation#treeItemTemplate}
 *
 *
 * @public
 * @remarks
 * Generates HTML Element: \<nimble-tree-item\>
 *
 */
export declare class TreeItem extends FoundationTreeItem {
    private treeView;
    connectedCallback(): void;
    disconnectedCallback(): void;
    private readonly handleSelectedChange;
    private clearTreeGroupSelection;
    private setGroupSelectionOnRootParentTreeItem;
    /**
     * This was copied directly from the FAST TreeItem implementation
     * @returns the root tree view
     */
    private getParentTreeView;
}

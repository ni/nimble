import { NumberField as FoundationNumberField } from '@microsoft/fast-foundation';
import { NumberFieldAppearance } from './types';
import '../icons/add';
import '../icons/exclamation-mark';
import '../icons/minus-wide';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-number-field': NumberField;
    }
}
/**
 * A nimble-styled HTML number input
 */
export declare class NumberField extends FoundationNumberField {
    appearance: NumberFieldAppearance;
    /**
     * A message explaining why the value is invalid.
     *
     * @public
     * @remarks
     * HTML Attribute: error-text
     */
    errorText: string | undefined;
    connectedCallback(): void;
}

import { Breadcrumb as FoundationBreadcrumb } from '@microsoft/fast-foundation';
import type { BreadcrumbAppearance } from './types';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-breadcrumb': Breadcrumb;
    }
}
/**
 * A nimble-styled breadcrumb
 */
export declare class Breadcrumb extends FoundationBreadcrumb {
    appearance: BreadcrumbAppearance;
}

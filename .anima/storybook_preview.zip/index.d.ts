import { ARIAGlobalStatesAndProperties, FoundationElement } from '@microsoft/fast-foundation';
import { UserDismissed } from '../patterns/dialog/types';
export { UserDismissed };
declare global {
    interface HTMLElementTagNameMap {
        'nimble-dialog': Dialog;
    }
}
/**
 * This is a workaround for an incomplete definition of the native dialog element:
 * https://github.com/microsoft/TypeScript/issues/48267
 * @internal
 */
export interface ExtendedDialog extends HTMLDialogElement {
    showModal(): void;
    close(): void;
}
/**
 * A nimble-styled dialog.
 */
export declare class Dialog<CloseReason = void> extends FoundationElement {
    static readonly UserDismissed: symbol;
    /**
     * @public
     * @description
     * Prevents dismissing the dialog via the Escape key
     */
    preventDismiss: boolean;
    /**
     * @public
     * @description
     * Hides the header of the dialog.
     */
    headerHidden: boolean;
    /**
     * @public
     * @description
     * Hides the footer of the dialog.
     */
    footerHidden: boolean;
    /**
     * The ref to the internal dialog element.
     *
     * @internal
     */
    readonly dialogElement: ExtendedDialog;
    /** @internal */
    footerIsEmpty: boolean;
    /** @internal */
    readonly slottedFooterElements?: HTMLElement[];
    /**
     * True if the dialog is open/showing, false otherwise
     */
    get open(): boolean;
    private resolveShow?;
    /**
     * Opens the dialog
     * @returns Promise that is resolved when the dialog is closed. The value of the resolved Promise is the reason value passed to the close() method, or UserDismissed if the dialog was closed via the ESC key.
     */
    show(): Promise<CloseReason | UserDismissed>;
    /**
     * Closes the dialog
     * @param reason An optional value indicating how/why the dialog was closed.
     */
    close(reason: CloseReason): void;
    slottedFooterElementsChanged(_prev: HTMLElement[] | undefined, next: HTMLElement[] | undefined): void;
    /**
     * @internal
     */
    cancelHandler(event: Event): boolean;
}
export interface Dialog extends ARIAGlobalStatesAndProperties {
}

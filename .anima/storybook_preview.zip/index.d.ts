import { BreadcrumbItem as FoundationBreadcrumbItem } from '@microsoft/fast-foundation';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-breadcrumb-item': BreadcrumbItem;
    }
}
/**
 * A nimble-styled breadcrumb item
 */
export declare class BreadcrumbItem extends FoundationBreadcrumbItem {
}

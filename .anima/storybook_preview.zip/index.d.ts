import { Menu as FoundationMenu } from '@microsoft/fast-foundation';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-menu': Menu;
    }
}
/**
 * A nimble-styled menu
 */
export declare class Menu extends FoundationMenu {
}

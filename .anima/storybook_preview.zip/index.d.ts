import { Radio as FoundationRadio } from '@microsoft/fast-foundation';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-radio': Radio;
    }
}
/**
 * A nimble-styled radio button
 */
export declare class Radio extends FoundationRadio {
}

import { Switch as FoundationSwitch } from '@microsoft/fast-foundation';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-switch': Switch;
    }
}
/**
 * A nimble-styled switch control.
 */
export declare class Switch extends FoundationSwitch {
}

import { ARIAGlobalStatesAndProperties, FoundationElement } from '@microsoft/fast-foundation';
import { UserDismissed } from '../patterns/dialog/types';
import { DrawerLocation } from './types';
export { UserDismissed };
declare global {
    interface HTMLElementTagNameMap {
        'nimble-drawer': Drawer;
    }
}
/**
 * Drawer control. Shows content in a panel on the left / right side of the screen,
 * which animates to be visible with a slide-in / slide-out animation.
 */
export declare class Drawer<CloseReason = void> extends FoundationElement {
    static readonly UserDismissed: symbol;
    location: DrawerLocation;
    preventDismiss: boolean;
    dialog: HTMLDialogElement;
    private closing;
    private resolveShow?;
    private closeReason;
    /**
     * True if the drawer is open, opening, or closing. Otherwise, false.
     */
    get open(): boolean;
    /**
     * Opens the drawer
     * @returns Promise that is resolved when the drawer finishes closing. The value of the resolved
     * Promise is the reason value passed to the close() method, or UserDismissed if the drawer was
     * closed via the ESC key.
     */
    show(): Promise<CloseReason | UserDismissed>;
    /**
     * Closes the drawer
     * @param reason An optional value indicating how/why the drawer was closed.
     */
    close(reason: CloseReason): void;
    /**
     * @internal
     */
    cancelHandler(event: Event): boolean;
    private readonly animationEndHandlerFunction;
    private openDialog;
    private closeDialog;
    private triggerAnimation;
    private animationEndHandler;
}
export interface Drawer extends ARIAGlobalStatesAndProperties {
}

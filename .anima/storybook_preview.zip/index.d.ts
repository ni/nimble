import { NumberField as FoundationNumberField } from '@microsoft/fast-foundation';
import { NumberFieldAppearance } from './types';
import type { ErrorPattern } from '../patterns/error/types';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-number-field': NumberField;
    }
}
/**
 * A nimble-styled HTML number input
 */
export declare class NumberField extends FoundationNumberField implements ErrorPattern {
    appearance: NumberFieldAppearance;
    /**
     * A message explaining why the value is invalid.
     *
     * @public
     * @remarks
     * HTML Attribute: error-text
     */
    errorText?: string;
    errorVisible: boolean;
    connectedCallback(): void;
}

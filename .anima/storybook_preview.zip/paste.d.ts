import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-paste': IconPaste;
    }
}
/**
 * The icon component for the 'paste' icon
 */
export declare class IconPaste extends Icon {
    constructor();
}

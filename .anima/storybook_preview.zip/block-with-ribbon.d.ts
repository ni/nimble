import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-block-with-ribbon': IconBlockWithRibbon;
    }
}
/**
 * The icon component for the 'blockWithRibbon' icon
 */
export declare class IconBlockWithRibbon extends Icon {
    constructor();
}

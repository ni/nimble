import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-circle-slash': IconCircleSlash;
    }
}
/**
 * The icon component for the 'circleSlash' icon
 */
export declare class IconCircleSlash extends Icon {
    constructor();
}

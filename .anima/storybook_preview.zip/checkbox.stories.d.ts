import type { Meta, StoryObj } from '@storybook/html';
import '../../all-components';
interface CheckboxArgs {
    label: string;
    checked: boolean;
    indeterminate: boolean;
    disabled: boolean;
}
declare const metadata: Meta<CheckboxArgs>;
export default metadata;
export declare const checkbox: StoryObj<CheckboxArgs>;

import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-circle-broken': IconCircleBroken;
    }
}
/**
 * The icon component for the 'circleBroken' icon
 */
export declare class IconCircleBroken extends Icon {
    constructor();
}

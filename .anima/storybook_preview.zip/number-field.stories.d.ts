import type { Meta, StoryObj } from '@storybook/html';
import '../../all-components';
import { NumberFieldAppearance } from '../types';
interface NumberFieldArgs {
    label: string;
    value: number;
    step: number;
    min: number;
    max: number;
    appearance: NumberFieldAppearance;
    disabled: boolean;
    errorVisible: boolean;
    errorText: string;
}
declare const metadata: Meta<NumberFieldArgs>;
export default metadata;
export declare const underlineNumberField: StoryObj<NumberFieldArgs>;
export declare const outlineNumberField: StoryObj<NumberFieldArgs>;
export declare const blockNumberField: StoryObj<NumberFieldArgs>;

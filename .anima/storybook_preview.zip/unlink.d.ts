import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-unlink': IconUnlink;
    }
}
/**
 * The icon component for the 'unlink' icon
 */
export declare class IconUnlink extends Icon {
    constructor();
}

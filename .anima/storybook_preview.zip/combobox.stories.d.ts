import type { Meta, StoryObj } from '@storybook/html';
import { ComboboxAutocomplete } from '@microsoft/fast-foundation';
import '../../all-components';
import '../../list-option';
import { DropdownPosition } from '../../patterns/dropdown/types';
interface ComboboxArgs {
    disabled: boolean;
    dropDownPosition: DropdownPosition;
    autocomplete: ComboboxAutocomplete;
    options: OptionArgs[];
    errorVisible: boolean;
    errorText: string;
    currentValue: string;
    appearance: string;
    placeholder: string;
}
interface OptionArgs {
    label: string;
    disabled: boolean;
}
declare const metadata: Meta<ComboboxArgs>;
export default metadata;
export declare const underlineCombobox: StoryObj<ComboboxArgs>;
export declare const outlineCombobox: StoryObj<ComboboxArgs>;
export declare const blockCombobox: StoryObj<ComboboxArgs>;

import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-running-arrow': IconRunningArrow;
    }
}
/**
 * The icon component for the 'runningArrow' icon
 */
export declare class IconRunningArrow extends Icon {
    constructor();
}

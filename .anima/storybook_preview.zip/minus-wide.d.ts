import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-minus-wide': IconMinusWide;
    }
}
/**
 * The icon component for the 'minusWide' icon
 */
export declare class IconMinusWide extends Icon {
    constructor();
}

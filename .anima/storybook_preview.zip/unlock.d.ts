import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-unlock': IconUnlock;
    }
}
/**
 * The icon component for the 'unlock' icon
 */
export declare class IconUnlock extends Icon {
    constructor();
}

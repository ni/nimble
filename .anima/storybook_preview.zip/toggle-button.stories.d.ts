import type { Meta, StoryObj } from '@storybook/html';
import '../../all-components';
interface ToggleButtonArgs {
    label: string;
    appearance: string;
    checked: boolean;
    disabled: boolean;
    icon: boolean;
    contentHidden: boolean;
    endIcon: boolean;
}
declare const metadata: Meta<ToggleButtonArgs>;
export default metadata;
export declare const outlineButton: StoryObj<ToggleButtonArgs>;
export declare const ghostButton: StoryObj<ToggleButtonArgs>;
export declare const blockButton: StoryObj<ToggleButtonArgs>;
export declare const iconButton: StoryObj<ToggleButtonArgs>;

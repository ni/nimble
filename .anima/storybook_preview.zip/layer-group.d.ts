import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-layer-group': IconLayerGroup;
    }
}
/**
 * The icon component for the 'layerGroup' icon
 */
export declare class IconLayerGroup extends Icon {
    constructor();
}

import type * as IconsNamespace from '../icons/all-icons';
declare type IconName = keyof typeof IconsNamespace;
interface IconMetadata {
    tags: string[];
}
export declare const iconMetadata: {
    readonly [key in IconName]: IconMetadata;
};
export {};

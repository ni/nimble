import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-cog-small-cog': IconCogSmallCog;
    }
}
/**
 * The icon component for the 'cogSmallCog' icon
 */
export declare class IconCogSmallCog extends Icon {
    constructor();
}

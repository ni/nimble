import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-gauge-simple': IconGaugeSimple;
    }
}
/**
 * The icon component for the 'gaugeSimple' icon
 */
export declare class IconGaugeSimple extends Icon {
    constructor();
}

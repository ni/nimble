import type { Meta, StoryObj } from '@storybook/html';
import '../../all-components';
interface SelectArgs {
    disabled: boolean;
    errorVisible: boolean;
    errorText: string;
    dropDownPosition: string;
    options: OptionArgs[];
    appearance: string;
}
interface OptionArgs {
    label: string;
    value: string;
    disabled: boolean;
}
declare const metadata: Meta<SelectArgs>;
export default metadata;
export declare const underlineSelect: StoryObj<SelectArgs>;
export declare const outlineSelect: StoryObj<SelectArgs>;
export declare const blockSelect: StoryObj<SelectArgs>;

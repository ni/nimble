import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-arrow-left-from-line': IconArrowLeftFromLine;
    }
}
/**
 * The icon component for the 'arrowLeftFromLine' icon
 */
export declare class IconArrowLeftFromLine extends Icon {
    constructor();
}

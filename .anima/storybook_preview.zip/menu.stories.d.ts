import type { Meta, StoryObj } from '@storybook/html';
import '../../all-components';
interface MenuArgs {
    itemOptions: ItemArgs[];
}
interface MenuItemArgs {
    text: string;
    disabled: boolean;
    icon: boolean;
}
interface ItemArgs extends MenuItemArgs {
    type: 'nimble-menu-item' | 'header' | 'hr';
}
declare const metadata: Meta<MenuArgs>;
export default metadata;
export declare const menuItem: StoryObj<MenuItemArgs>;
export declare const menu: StoryObj<MenuArgs>;
export declare const nestedMenu: StoryObj<MenuArgs>;
export declare const customMenu: StoryObj<MenuArgs>;

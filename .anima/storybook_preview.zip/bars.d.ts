import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-bars': IconBars;
    }
}
/**
 * The icon component for the 'bars' icon
 */
export declare class IconBars extends Icon {
    constructor();
}

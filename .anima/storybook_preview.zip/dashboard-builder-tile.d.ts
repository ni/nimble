import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-dashboard-builder-tile': IconDashboardBuilderTile;
    }
}
/**
 * The icon component for the 'dashboardBuilderTile' icon
 */
export declare class IconDashboardBuilderTile extends Icon {
    constructor();
}

import type { Meta, Story } from '@storybook/html';
declare const metadata: Meta;
export default metadata;
export declare const toolbarThemeMatrix: Story;
export declare const hiddenToolbar: Story;

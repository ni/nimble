import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-arrow-rotate-right': IconArrowRotateRight;
    }
}
/**
 * The icon component for the 'arrowRotateRight' icon
 */
export declare class IconArrowRotateRight extends Icon {
    constructor();
}

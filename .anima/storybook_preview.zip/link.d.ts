import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-link': IconLink;
    }
}
/**
 * The icon component for the 'link' icon
 */
export declare class IconLink extends Icon {
    constructor();
}

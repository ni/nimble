import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-copy': IconCopy;
    }
}
/**
 * The icon component for the 'copy' icon
 */
export declare class IconCopy extends Icon {
    constructor();
}

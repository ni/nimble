import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-thumbtack': IconThumbtack;
    }
}
/**
 * The icon component for the 'thumbtack' icon
 */
export declare class IconThumbtack extends Icon {
    constructor();
}

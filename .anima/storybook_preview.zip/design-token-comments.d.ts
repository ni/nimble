import type * as TokensNamespace from './design-tokens';
declare type TokenName = keyof typeof TokensNamespace;
export declare const comments: {
    readonly [key in TokenName]: string | null;
};
export {};

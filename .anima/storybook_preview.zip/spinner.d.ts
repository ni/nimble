import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-spinner': IconSpinner;
    }
}
/**
 * The icon component for the 'spinner' icon
 */
export declare class IconSpinner extends Icon {
    constructor();
}

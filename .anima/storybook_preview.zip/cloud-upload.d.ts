import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-cloud-upload': IconCloudUpload;
    }
}
/**
 * The icon component for the 'cloudUpload' icon
 */
export declare class IconCloudUpload extends Icon {
    constructor();
}

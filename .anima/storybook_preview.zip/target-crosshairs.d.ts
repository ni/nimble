import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-target-crosshairs': IconTargetCrosshairs;
    }
}
/**
 * The icon component for the 'targetCrosshairs' icon
 */
export declare class IconTargetCrosshairs extends Icon {
    constructor();
}

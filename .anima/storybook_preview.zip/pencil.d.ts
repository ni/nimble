import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-pencil': IconPencil;
    }
}
/**
 * The icon component for the 'pencil' icon
 */
export declare class IconPencil extends Icon {
    constructor();
}

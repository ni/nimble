import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-file': IconFile;
    }
}
/**
 * The icon component for the 'file' icon
 */
export declare class IconFile extends Icon {
    constructor();
}

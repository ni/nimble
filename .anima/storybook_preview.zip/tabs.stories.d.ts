import type { Meta, StoryObj } from '@storybook/html';
import '../../all-components';
interface TabsArgs {
    tabs: TabArgs[];
    toolbar: string;
}
interface TabArgs {
    label: string;
    content: string;
    disabled: boolean;
}
declare const metadata: Meta<TabsArgs>;
export default metadata;
export declare const tabs: StoryObj<TabsArgs>;
export declare const toolbar: StoryObj<TabsArgs>;

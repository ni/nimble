import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-list-tree': IconListTree;
    }
}
/**
 * The icon component for the 'listTree' icon
 */
export declare class IconListTree extends Icon {
    constructor();
}

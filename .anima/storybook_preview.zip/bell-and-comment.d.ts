import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-bell-and-comment': IconBellAndComment;
    }
}
/**
 * The icon component for the 'bellAndComment' icon
 */
export declare class IconBellAndComment extends Icon {
    constructor();
}

import type { Meta, StoryObj } from '@storybook/html';
import '../../all-components';
import { Dialog } from '..';
import type { TextField } from '../../text-field';
import { ExampleContentType } from './types';
interface DialogArgs {
    title: string;
    subtitle: string;
    headerHidden: boolean;
    footerHidden: boolean;
    includeFooterButtons: boolean;
    preventDismiss: boolean;
    content: ExampleContentType;
    show: undefined;
    close: undefined;
    dialogRef: Dialog<string>;
    textFieldRef: TextField;
    openAndHandleResult: (dialogRef: Dialog<string>, textFieldRef: TextField) => void;
}
declare const metadata: Meta<DialogArgs>;
export default metadata;
export declare const dialog: StoryObj<DialogArgs>;

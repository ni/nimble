import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-clock-cog': IconClockCog;
    }
}
/**
 * The icon component for the 'clockCog' icon
 */
export declare class IconClockCog extends Icon {
    constructor();
}

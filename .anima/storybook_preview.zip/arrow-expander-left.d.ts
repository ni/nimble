import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-arrow-expander-left': IconArrowExpanderLeft;
    }
}
/**
 * The icon component for the 'arrowExpanderLeft' icon
 */
export declare class IconArrowExpanderLeft extends Icon {
    constructor();
}

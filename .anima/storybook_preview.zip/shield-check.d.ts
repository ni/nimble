import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-shield-check': IconShieldCheck;
    }
}
/**
 * The icon component for the 'shieldCheck' icon
 */
export declare class IconShieldCheck extends Icon {
    constructor();
}

import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-pot-with-lid': IconPotWithLid;
    }
}
/**
 * The icon component for the 'potWithLid' icon
 */
export declare class IconPotWithLid extends Icon {
    constructor();
}

import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-download': IconDownload;
    }
}
/**
 * The icon component for the 'download' icon
 */
export declare class IconDownload extends Icon {
    constructor();
}

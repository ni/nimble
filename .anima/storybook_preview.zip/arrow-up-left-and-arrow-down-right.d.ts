import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-arrow-up-left-and-arrow-down-right': IconArrowUpLeftAndArrowDownRight;
    }
}
/**
 * The icon component for the 'arrowUpLeftAndArrowDownRight' icon
 */
export declare class IconArrowUpLeftAndArrowDownRight extends Icon {
    constructor();
}

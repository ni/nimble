import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-clock': IconClock;
    }
}
/**
 * The icon component for the 'clock' icon
 */
export declare class IconClock extends Icon {
    constructor();
}

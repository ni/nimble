import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-true-false-rectangle': IconTrueFalseRectangle;
    }
}
/**
 * The icon component for the 'trueFalseRectangle' icon
 */
export declare class IconTrueFalseRectangle extends Icon {
    constructor();
}

import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-bell': IconBell;
    }
}
/**
 * The icon component for the 'bell' icon
 */
export declare class IconBell extends Icon {
    constructor();
}

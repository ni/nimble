import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-computer-and-monitor': IconComputerAndMonitor;
    }
}
/**
 * The icon component for the 'computerAndMonitor' icon
 */
export declare class IconComputerAndMonitor extends Icon {
    constructor();
}

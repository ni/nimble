import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-webvi-host': IconWebviHost;
    }
}
/**
 * The icon component for the 'webviHost' icon
 */
export declare class IconWebviHost extends Icon {
    constructor();
}

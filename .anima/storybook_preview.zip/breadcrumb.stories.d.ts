import type { Meta, StoryObj } from '@storybook/html';
import '../../all-components';
import { BreadcrumbAppearance } from '../types';
interface BreadcrumbArgs {
    options: ItemArgs[];
    appearance: keyof typeof BreadcrumbAppearance;
    allowNavigation: boolean;
}
interface ItemArgs {
    href?: string;
    target?: string;
    label: string;
}
interface BreadcrumbItemArgs extends ItemArgs {
    allowNavigation: boolean;
}
declare const metadata: Meta<BreadcrumbArgs>;
export default metadata;
export declare const _standardBreadcrumb: StoryObj<BreadcrumbArgs>;
export declare const breadcrumbItem: StoryObj<BreadcrumbItemArgs>;

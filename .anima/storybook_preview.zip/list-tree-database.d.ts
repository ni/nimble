import { Icon } from '../icon-base';
declare global {
    interface HTMLElementTagNameMap {
        'nimble-icon-list-tree-database': IconListTreeDatabase;
    }
}
/**
 * The icon component for the 'listTreeDatabase' icon
 */
export declare class IconListTreeDatabase extends Icon {
    constructor();
}

import type { Meta, StoryObj } from '@storybook/html';
import { DrawerWidthOptions, ExampleContentType } from './types';
import { DrawerLocation, DrawerState } from '../types';
import type { Drawer } from '..';
import '../../all-components';
interface DrawerArgs {
    location: DrawerLocation;
    state: DrawerState;
    modal: string;
    preventDismiss: boolean;
    content: ExampleContentType;
    width: DrawerWidthOptions;
    drawerRef: Drawer;
    toggleDrawer: (x: Drawer) => void;
}
declare const metadata: Meta<DrawerArgs>;
export default metadata;
export declare const drawer: StoryObj<DrawerArgs>;

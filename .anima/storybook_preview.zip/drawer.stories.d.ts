import type { Meta, StoryObj } from '@storybook/html';
import { DrawerWidthOptions, ExampleContentType } from './types';
import { DrawerLocation } from '../types';
import { Drawer } from '..';
import '../../all-components';
import type { TextField } from '../../text-field';
interface DrawerArgs {
    location: DrawerLocation;
    preventDismiss: boolean;
    content: ExampleContentType;
    width: DrawerWidthOptions;
    show: undefined;
    close: undefined;
    drawerRef: Drawer<string>;
    textFieldRef: TextField;
    openAndHandleResult: (drawerRef: Drawer<string>, textFieldRef: TextField) => void;
}
declare const metadata: Meta<DrawerArgs>;
export default metadata;
export declare const drawer: StoryObj<DrawerArgs>;

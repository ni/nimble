/**
 * Singleton utility to watch the prefers-reduced-motion media value
 */
export declare const prefersReducedMotionMediaQuery: MediaQueryList;
